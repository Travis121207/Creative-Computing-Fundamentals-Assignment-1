let x;
let speed = 1;

async function setup() {
  img = await loadImage('clouds.png')
  createCanvas(800, 800);
  x = 0
}

function draw() {

  image(img, -40,-120)
 
  moon(); //Part A (v)
  terrain();
  house();
  car();
  spacecraft();
  alien();
  
}

function moon(){ //Part A (iii)
  

  x += speed;

  if (x > width + 25) {
    x = -25;
  }
  
  fill(255, 245, 190)
  circle(x, 50, 50);
}


function alien(){
  strokeWeight(0);
  fill(0,255,0);
  ellipse(200,485,15,40);
  rect(180,475,40,5);
  ellipse(225,477.5,10,10);
  ellipse(175,477.5,10,10);
  fill(0);
  ellipse(225,477.5,5,5);
  ellipse(175,477.5,5,5);
  fill(0,255,0);
  ellipse(200,460,20,20);
  rect(198,445,4,30);
  fill(0);
  ellipse(200,445,5,5);
  ellipse(195,457,5,5);
  ellipse(205,457,5,5);
  fill(0,200,0);
  ellipse(200,485,10,20);
}

function terrain(){
  strokeWeight(0);
  fill(0,150,0);
  rect(0,475,800,400);
  

}

function spacecraft(){ //Part A (iv)
  strokeWeight(0);
  fill(random(255),random(255),random(255));
  ellipse(200,270,25,25);
  ellipse(170,270,25,25);
  ellipse(230,270,25,25);
  fill(50);
  ellipse(200,200,75,75);
  triangle(200,200,265,270,135,270);
  fill(random(255),random(255),random(255));
  ellipse(200,200,20,20);
  ellipse(175,200,20,20);
  ellipse(225,200,20,20);
  
}

function house(){ //Part A (i)
  strokeWeight(1);
  fill(150);
  rect(425,350,10,50);
  fill(255,0,0);
  rect(400,400,90,90);
  fill(165, 42, 42);
  triangle(445,350,490,400,400,400);
  //Part B (i)
  if((mouseX>435)&&(mouseX<455)&&(mouseY>450)&&(mouseY<490)){
    fill(random(255),random(255),random(255));
    
  }
  else{
    fill(173,216,230)
  }
  rect(410,420,20,20);
  rect(460,420,20,20);
  fill(165, 42, 42);
  rect(435,450,20,40);
  fill(173,216,230);
  rect(440,455,10,10);
  fill(150,150,0);
  ellipse(440,470,5,5);
  fill(100);
  ellipse(430,340,10,10);
  ellipse(415,330,10,10);
  ellipse(405,320,10,10);
  fill(225);
  line(420,420,420,440);
  line(410,430,430,430);
  line(470,420,470,440);
  line(460,430,480,430);
}
  

function car() { //Part A (ii)
  strokeWeight(0);
  fill(0);
  ellipse(525,490,15,15);
  ellipse(565,490,15,15);
  fill(80);
  rect(510,465,70,25);
  rect(510,450,30,15);
  triangle(540,450,560,465,540,465);
  fill(173,216,230);
  triangle(542,454,556,464,542,464);
  rect(515,453,20,10);
  strokeWeight(1);
  
  
}

// Extra: My extra addition is the alien beneath the UFO
