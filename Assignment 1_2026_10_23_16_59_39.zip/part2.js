let x, y;
const r = 25; 
const step = 5; 

function setup() {
  createCanvas(800, 800);
  x = width / 2;
  y = height / 2;
}

function draw() {
  background(220);

  // Move while keys are held
  if (keyIsDown(LEFT_ARROW)) {
    x = max(x - step, r);
  }
  if (keyIsDown(RIGHT_ARROW)) {
    x = min(x + step, width - r);
  }
  if (keyIsDown(UP_ARROW)) {
    y = max(y - step, r);
  }
  if (keyIsDown(DOWN_ARROW)) {
    y = min(y + step, height - r);
  }

  rocket(x, y, r * 2);
}

function rocket(x, y, size) {
  push();
  translate(x, y);
  const s = size / 100; 
  scale(s);

  fill(255, 150, 0);
  triangle(0, -50, 30, -20, -30, -20);   
  fill(255);
  rect(-30, -20, 60, 150);               
  fill(255, 160, 0);
  rect(-30, 0, 60, 20);                  
  rect(-30, 40, 60, 20);                 
  rect(-30, 80, 60, 20);                 
  triangle(30, 40, 60, 140, 30, 140);    
  triangle(-30, 40, -30, 140, -60, 140); 
  fill(150);
  rect(-20, 130, 20, 25);                
  rect(0, 130, 20, 25);                  

  pop();
}